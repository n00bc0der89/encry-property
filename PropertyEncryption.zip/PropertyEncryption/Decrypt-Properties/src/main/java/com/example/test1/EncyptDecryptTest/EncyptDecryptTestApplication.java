package com.example.test1.EncyptDecryptTest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncyptDecryptTestApplication implements CommandLineRunner {

	@Value("${spring.liquibase.default-schema}")
	String liq_default_schema;
	@Value("${spring.datasource.username}")
	String data_username;
	@Value("${spring.datasource.password}")
	String data_pass;
	@Value("${spring.liquibase.user}")
	String liq_user;
	@Value("${spring.liquibase.password}")
	String liq_pass;
	@Value("${ebrd.dtm-service.user}")
	String dtm_user;
	@Value("${ebrd.dtm-service.password}")
	String dtm_pass;
	@Value("${ebrd.dtm-service.ssl.trust-store.password}")
	String dtm_service_ssl;
	
	
	
	

	@Override
	public void run(String... args) throws Exception {
		System.out.println("liquibase Schema is: " + liq_default_schema +"\n"+ "Liquibase UserName is: " + liq_user
				+"\n"+ "Liquibase Password is: " + liq_pass+"\n"+"Datasource UserName is: " + data_username
				 +"\n"+ "Datasource Password is: " + data_pass +"\n" +"DTm Service User : "+dtm_user+"\n"+"DTM service password : "+dtm_pass+"\n"+"DTM service SSl password :" +dtm_service_ssl );
	}

	public static void main(String[] args) {
		SpringApplication.run(EncyptDecryptTestApplication.class, args);
	}

}
