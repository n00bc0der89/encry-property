package com.example.ExternalProperties;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Properties;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;


@SpringBootApplication
@EnableEncryptableProperties 
public class ExternalPropertiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExternalPropertiesApplication.class, args);

		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		
		//change JASYPT_PASSWORD value with original password
		encryptor.setPassword("JASYPT_PASSWORD");
		
		Properties props = new EncryptableProperties(encryptor);
		try {
			props.load(new FileInputStream(
					"C:/ExternalProperties/src/main/resources/application.properties"));

			Enumeration<Object> propsEnum = props.keys();
			while (propsEnum.hasMoreElements()) {
				String propertyKey = propsEnum.nextElement().toString();
				System.out.println(" propertyKey : " + propertyKey);
				props.setProperty(propertyKey,encryptor.encrypt(props.getProperty(propertyKey)));
				
			}
			System.out.println(" Props : " + props);
			
			OutputStream output = new FileOutputStream(
					"C:/ExternalProperties/src/main/resources/application2.properties");
			
			props.store(output, null);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
